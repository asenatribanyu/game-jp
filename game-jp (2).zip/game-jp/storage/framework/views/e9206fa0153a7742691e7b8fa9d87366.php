<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="shortcut icon" href="<?php echo e(asset('assets/icon/icon1.ico')); ?>"> 
        <title>Game Jp</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" 
                integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
        
        
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    </head>
    
    <body>
    <div class="button-container">
        <button type="button" class="alert alert-info">Hiragana</button>
        <button type="button" class="alert alert-danger">Katakana</button>  
    </div>

    <table class="table table-secondary table-striped small-table">
    <thead>
    <tr>
      <th scope="col">Romaji</th>
      <th scope="col">Hiragana</th>
      <th scope="col">Katakana</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>a</td>
      <td>あ</td>
      <td>ア</td>
    </tr>
    <tr>
      <td>i</td>
      <td>い</td>
      <td>イ</td>
    </tr>
    <tr> 
      <td>u</td>
      <td>う</td>
      <td>ウ</td>
    </tr>
    <tr> 
      <td>e</td>
      <td>え</td>
      <td>エ</td>
    </tr>
    <tr> 
      <td>o</td>
      <td>お</td>
      <td>オ</td>
    </tr>
    <tr> 
      <td>ka</td>
      <td>か</td>
      <td>カ</td>
    </tr>
    <tr> 
      <td>ki</td>
      <td>き</td>
      <td>キ</td>
    </tr>
    <tr> 
      <td>ku</td>
      <td>く</td>
      <td>ク</td>
    </tr>
    <tr> 
      <td>ke</td>
      <td>け</td>
      <td>ケ</td>
    </tr>
    <tr> 
      <td>ko</td>
      <td>こ</td>
      <td>コ</td>
    </tr>
    <tr> 
      <td>sa</td>
      <td>さ</td>
      <td>サ</td>
    </tr>
    <tr> 
      <td>shi</td>
      <td>し</td>
      <td>シ</td>
    </tr>
    <tr> 
      <td>su</td>
      <td>す</td>
      <td>ス</td>
    </tr>
    <tr> 
      <td>se</td>
      <td>せ</td>
      <td>セ</td>
    </tr>
    <tr> 
      <td>so</td>
      <td>そ</td>
      <td>ソ </td>
    </tr>
    <tr> 
      <td>ta</td>
      <td>た</td>
      <td>タ</td>
    </tr>
    <tr> 
      <td>ka</td>
      <td>か</td>
      <td>カ</td>
    </tr>
    <tr> 
      <td>ka</td>
      <td>か</td>
      <td>カ</td>
    </tr>
    <tr> 
      <td>ka</td>
      <td>か</td>
      <td>カ</td>
    </tr>
    <tr> 
      <td>ka</td>
      <td>か</td>
      <td>カ</td>
    </tr>
    <tr> 
      <td>ka</td>
      <td>か</td>
      <td>カ</td>
    </tr>
    <tr> 
      <td>ka</td>
      <td>か</td>
      <td>カ</td>
    </tr>
    <tr> 
      <td>ka</td>
      <td>か</td>
      <td>カ</td>
    </tr>
    <tr> 
      <td>ka</td>
      <td>か</td>
      <td>カ</td>
    </tr>
    <tr> 
      <td>ka</td>
      <td>か</td>
      <td>カ</td>
    </tr>
  </tbody>
    </table>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" 
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>

    </body>
</html>
<?php /**PATH C:\Users\USER\Desktop\game-jp\resources\views/welcome.blade.php ENDPATH**/ ?>